package thread;
// Step 1: Create a thread by extending the 'Thread' class
class MyThread extends Thread {
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread 1 - Count: " + i);
            try {
                // Sleep for 1 second
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

// Step 3: Create a thread by implementing the "Runnable" interface
class MyRunnable implements Runnable {
    @Override
    public void run() {
        for (char ch = 'A'; ch <= 'E'; ch++) {
            System.out.println("Thread 2 - Character: " + ch);
            try {
                // Sleep for 1 second
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

// Step 4: Main method to run the program
public class ThreadExample {
    public static void main(String[] args) {

        // Step 5: Create instances of both threads
        MyThread thread1 = new MyThread();
        Thread thread2 = new Thread(new MyRunnable());

        // Step 6: Start both threads
        thread1.start();
        thread2.start();
    }
}
