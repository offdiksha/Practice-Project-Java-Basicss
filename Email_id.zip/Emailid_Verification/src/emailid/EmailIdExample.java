package emailid;

import java.util.Scanner;

public class EmailIdExample {

    public static void main(String[] args) {
        // Sample array of email IDs
        String[] emailArray = {"john@example.com", "mary@example.com", "alex@example.com"};

        // Scanner to take user input
        Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter the email ID to search: ");
        String searchEmail = scanner.nextLine();

        // Call the searchEmail method to find the email
        boolean found = searchEmail(emailArray, searchEmail);

        // Display result
        if (found) {
            System.out.println("Email ID found!");
        } else {
            System.out.println("Email ID not found.");
        }

        // Close scanner
        scanner.close();
    }

    // Method to search for the email in the array
    private static boolean searchEmail(String[] emailArray, String searchEmail) {
        for (String email : emailArray) {
            if (email.equals(searchEmail)) {
                return true; // Email found
            }
        }
        return false; // Email not found
    }
}
