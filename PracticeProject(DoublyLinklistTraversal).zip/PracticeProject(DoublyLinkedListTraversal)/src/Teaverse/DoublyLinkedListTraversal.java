package Traverse;

class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedListTraversal {
    private Node head;

    public static void main(String[] args) {
        DoublyLinkedListTraversal doublyLinkedList = new DoublyLinkedListTraversal();

        // Sample doubly linked list
        doublyLinkedList.insertEnd(1);
        doublyLinkedList.insertEnd(2);
        doublyLinkedList.insertEnd(3);
        doublyLinkedList.insertEnd(4);
        doublyLinkedList.insertEnd(5);

        System.out.println("Forward Traversal:");
        doublyLinkedList.traverseForward();

        System.out.println("\nBackward Traversal:");
        doublyLinkedList.traverseBackward();
    }

    // Insert a new node at the end of the doubly linked list
    private void insertEnd(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    // Traverse the doubly linked list in the forward direction
    private void traverseForward() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Traverse the doubly linked list in the backward direction
    private void traverseBackward() {
        Node current = head;

        // Move to the end of the list
        while (current != null && current.next != null) {
            current = current.next;
        }

        // Traverse backward
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
