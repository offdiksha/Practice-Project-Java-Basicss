package delete.occurrence;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class DeleteOccurrenceLinkedList {
    private Node head;

    public static void main(String[] args) {
        DeleteOccurrenceLinkedList linkedList = new DeleteOccurrenceLinkedList();

        // Sample linked list
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);

        System.out.println("Original Linked List:");
        linkedList.display();

        // Delete the first occurrence of key 3
        int keyToDelete = 3;
        linkedList.deleteFirstOccurrence(keyToDelete);

        System.out.println("\nLinked List after deleting first occurrence of " + keyToDelete + ":");
        linkedList.display();
    }

    // Insert a new node at the end of the linked list
    private void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Delete the first occurrence of a key in the linked list
    private void deleteFirstOccurrence(int key) {
        Node current = head;
        Node prev = null;

        // Traverse the list to find the key
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If key is not found
        if (current == null) {
            System.out.println("Key " + key + " not found in the linked list.");
            return;
        }

        // If key is found, update the pointers to skip the node
        if (prev == null) {
            // If the key is in the first node
            head = current.next;
        } else {
            // If the key is in a non-first node
            prev.next = current.next;
        }
    }

    // Display the elements of the linked list
    private void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}



