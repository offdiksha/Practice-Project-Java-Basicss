package innerclassesdemos;

// Main class (OuterClass)
public class OuterClass {

    // Instance variable
    private String outerMessage = "This is the outer class.";

    // Inner class
    public class InnerClass {

        // Instance variable in the inner class
        private String innerMessage = "This is the inner class.";

        // Inner class method accessing outer class variables
        public void displayMessages() {
            System.out.println("Outer Message: " + outerMessage);
            System.out.println("Inner Message: " + innerMessage);
        }
    }

    // Main method
    public static void main(String[] args) {
        // Creating an object of the outer class
        OuterClass outerObject = new OuterClass();

        // Creating an object of the inner class
        OuterClass.InnerClass innerObject = outerObject.new InnerClass();

        // Accessing inner class method
        innerObject.displayMessages();
    }
}