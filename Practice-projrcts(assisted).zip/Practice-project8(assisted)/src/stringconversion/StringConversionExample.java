package stringconversion;

public class StringConversionExample {
    public static void main(String[] args) {
        // Step 1: Creating a String
        String originalString = "Hello, World!";

        // Step 2: Converting String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);

        // Step 3: Converting String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);

        // Step 4: Displaying the results
        System.out.println("Original String: " + originalString);
        System.out.println("String to StringBuffer: " + stringBuffer);
        System.out.println("String to StringBuilder: " + stringBuilder);
    }
}