//Package declaration
package Example;

// Main class
public class AccessModifiersExample {

    // Public method accessible from anywhere
    public static void main(String[] args) {
        MyClass myObject = new MyClass();

        // Accessing public method
        myObject.publicMethod();

          }
}

// Another class with various access modifiers
class MyClass {

    // Public method
    public void publicMethod() {
        System.out.println("Public method can be accessed from anywhere");
    }

    // Private method
    private void privateMethod() {
        System.out.println("Private method can only be accessed within the same class");
    }

    // Protected method
    protected void protectedMethod() {
        System.out.println("Protected method can be accessed within the same package and subclasses");
    }

    // Default method (package-private)
    void defaultMethod() {
        System.out.println("Default method can only be accessed within the same package");
    }
}