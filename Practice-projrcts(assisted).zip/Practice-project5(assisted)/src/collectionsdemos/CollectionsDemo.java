package collectionsdemos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Main class
public class CollectionsDemo {

    // Main method
    public static void main(String[] args) {
        // Example of List (ArrayList)
        List<String> stringList = new ArrayList<>();
        stringList.add("Apple");
        stringList.add("Banana");
        stringList.add("Orange");

        // Example of Map (HashMap)
        Map<Integer, String> numberMap = new HashMap<>();
        numberMap.put(1, "One");
        numberMap.put(2, "Two");
        numberMap.put(3, "Three");

        // Displaying elements in the List
        System.out.println("List Elements:");
        for (String fruit : stringList) {
            System.out.println(fruit);
        }

        // Displaying elements in the Map
        System.out.println("\nMap Elements:");
        for (Map.Entry<Integer, String> entry : numberMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}