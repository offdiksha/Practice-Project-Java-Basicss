package constructordemos;

// Main class
public class ConstructorDemo {

    // Instance variables
    private String message;

    // Default constructor
    public ConstructorDemo() {
        this.message = "This is the default constructor.";
    }

    // Parameterized constructor
    public ConstructorDemo(String customMessage) {
        this.message = customMessage;
    }

    // Method to display the message
    public void displayMessage() {
        System.out.println(message);
    }

    // Main method
    public static void main(String[] args) {
        // Creating objects with different constructors
        ConstructorDemo defaultConstructorObj = new ConstructorDemo();
        ConstructorDemo paramConstructorObj = new ConstructorDemo("This is a custom message.");

        // Displaying messages
        defaultConstructorObj.displayMessage();
        paramConstructorObj.displayMessage();
    }
}