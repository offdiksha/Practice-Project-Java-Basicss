package mapsdemos;

import java.util.HashMap;
import java.util.Map;

// Main class
public class MapsDemo {

    // Main method
    public static void main(String[] args) {
        // Example of Map (HashMap)
        Map<Integer, String> numberMap = new HashMap<>();

        // Adding elements to the map
        numberMap.put(1, "One");
        numberMap.put(2, "Two");
        numberMap.put(3, "Three");

        // Displaying elements in the Map
        System.out.println("Map Elements:");
        for (Map.Entry<Integer, String> entry : numberMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Checking if a key exists
        int keyToCheck = 2;
        if (numberMap.containsKey(keyToCheck)) {
            System.out.println("\nKey " + keyToCheck + " exists in the map.");
        } else {
            System.out.println("\nKey " + keyToCheck + " does not exist in the map.");
        }
    }
}
