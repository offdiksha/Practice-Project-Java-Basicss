package arrayverification;

public class ArrayVerificationExample {
    public static void main(String[] args) {
        // Step 1: Creating and initializing an array
        int[] numbers = {1, 2, 3, 4, 5};

        // Step 2: Accessing elements of the array
        System.out.println("Array Elements:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }

        // Step 3: Modifying an element in the array
        numbers[2] = 10;
        System.out.println("\nArray after modification:");
        for (int number : numbers) {
            System.out.println("Element: " + number);
        }

        // Step 4: Array length
        System.out.println("\nArray Length: " + numbers.length);

        // Step 5: Creating a 2D array
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println("\n2D Array Elements:");
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}