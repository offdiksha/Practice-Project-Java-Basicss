// Package declaration
package methoddemos;

// Main class
public class MethodDemo {

    // Main method
    public static void main(String[] args) {
        // Creating an object of the class
        MethodDemo demoObject = new MethodDemo();

        // Calling various methods
        demoObject.simpleMethod();
        int result = demoObject.addNumbers(5, 7);
        System.out.println("Sum of numbers: " + result);
        String greeting = demoObject.createGreeting("Hello", "World");
        System.out.println(greeting);
    }

    // Simple method with no parameters and no return value
    public void simpleMethod() {
        System.out.println("This is a simple method without parameters and return value.");
    }

    // Method with parameters and a return value
    public int addNumbers(int num1, int num2) {
        return num1 + num2;
    }

    // Method with parameters and return value (String concatenation)
    public String createGreeting(String greeting, String name) {
        return greeting + ", " + name + "!";
    }
}