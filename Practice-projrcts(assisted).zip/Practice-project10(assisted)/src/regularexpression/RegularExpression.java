package regularexpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {
    public static void main(String[] args) {
        // Step 1: Verifying a simple pattern match
        String input1 = "Hello, world!";
        String pattern1 = "Hello,.*";
        boolean match1 = Pattern.matches(pattern1, input1);
        System.out.println("Pattern 1 Match: " + match1);

        // Step 2: Using Matcher to find and group matches
        String input2 = "The price is $15.99 and $20.50.";
        String pattern2 = "\\$(\\d+\\.\\d{2})";
        Pattern patternObject = Pattern.compile(pattern2);
        Matcher matcher = patternObject.matcher(input2);

        System.out.println("\nPattern 2 Matches:");
        while (matcher.find()) {
            String match = matcher.group();
            System.out.println("Found: " + match);
        }

        // Step 3: Splitting a string using a regex
        String input3 = "apple,orange,banana,grape";
        String[] fruits = input3.split(",");
        System.out.println("\nFruits:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}