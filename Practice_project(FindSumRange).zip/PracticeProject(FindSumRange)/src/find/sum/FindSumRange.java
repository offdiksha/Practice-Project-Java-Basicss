package find.sum;

public class FindSumRange {

    public static void main(String[] args) {
        // Sample array
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        
        // Range (L and R)
        int L = 2;
        int R = 6;

        // Find the sum of elements in the range [L, R]
        int sumInRange = findSumInRange(array, L, R);

        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
    }

    private static int findSumInRange(int[] arr, int L, int R) {
        int n = arr.length;

        // Check if the range is valid
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range");
            return -1; // Indicates an error or an invalid range
        }

        int sum = 0;

        // Sum the elements in the specified range [L, R]
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        return sum;
    }
}
