package find.element;


import java.util.Arrays;

public class FindFourthSmallest {

    public static void main(String[] args) {
        // Sample unsorted list
        int[] unsortedList = {12, 8, 15, 5, 10, 9, 3};

        System.out.println("Unsorted List: " + Arrays.toString(unsortedList));

        // Find the fourth smallest element
        int fourthSmallest = findFourthSmallest(unsortedList);

        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    private static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            // Handle the case where the array has less than 4 elements
            System.out.println("Array should have at least 4 elements");
            return -1; // Indicates an error or no valid fourth smallest element
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // Return the fourth element (index 3) in the sorted array
        return arr[3];
    }
}
