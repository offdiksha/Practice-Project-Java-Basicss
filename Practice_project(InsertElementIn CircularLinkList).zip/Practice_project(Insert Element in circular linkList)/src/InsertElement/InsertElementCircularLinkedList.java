package InsertElement;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class InsertElementCircularLinkedList {
    private Node head;

    public static void main(String[] args) {
        InsertElementCircularLinkedList circularLinkedList = new InsertElementCircularLinkedList();

        // Sample circular linked list
        circularLinkedList.insertSorted(2);
        circularLinkedList.insertSorted(4);
        circularLinkedList.insertSorted(6);
        circularLinkedList.insertSorted(8);

        System.out.println("Original Circular Linked List:");
        circularLinkedList.display();

        // Insert a new element (e.g., 5) into the sorted circular linked list
        int newElement = 5;
        circularLinkedList.insertSorted(newElement);

        System.out.println("\nCircular Linked List after inserting " + newElement + ":");
        circularLinkedList.display();
    }

    // Insert a new element into the sorted circular linked list
    private void insertSorted(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            // If the list is empty, make the new node the head and point it to itself
            head = newNode;
            newNode.next = head;
        } else if (data <= head.data) {
            // If the new element is less than or equal to the head, insert it at the beginning
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
            // Traverse the list to find the correct position to insert the new element
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }

            // Insert the new element between current and current.next
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Display the elements of the circular linked list
    private void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}
