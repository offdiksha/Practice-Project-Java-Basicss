package rotate.array;

import java.util.Arrays;

public class RotateArray {

    public static void main(String[] args) {
        // Sample array
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        System.out.println("Original Array: " + Arrays.toString(array));

        // Number of steps to rotate the array
        int steps = 5;

        // Right rotate the array by 5 steps
        rotateArrayRight(array, steps);

        System.out.println("Rotated Array: " + Arrays.toString(array));
    }

    private static void rotateArrayRight(int[] arr, int steps) {
        int length = arr.length;

        // Handle cases where steps exceed the array length
        steps = steps % length;

        // Create a temporary array to store the rotated elements
        int[] temp = new int[steps];

        // Store the last 'steps' elements in the temporary array
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[length - steps + i];
        }

        // Shift the remaining elements to the right
        for (int i = length - steps - 1; i >= 0; i--) {
            arr[i + steps] = arr[i];
        }

        // Copy the elements from the temporary array to the beginning of the array
        System.arraycopy(temp, 0, arr, 0, steps);
    }
}


